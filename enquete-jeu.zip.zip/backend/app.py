from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import ollama
import os

# -------- CONFIG OLLAMA --------
os.environ["OLLAMA_HOST"] = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
MODEL = os.getenv("OLLAMA_MODEL", "phi3:mini")

# -------- APP FASTAPI --------
app = FastAPI(title="Jeu d'enquête 🔍 API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatItem(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: list[ChatItem]

class ChatResponse(BaseModel):
    reply: str

SYSTEM_PROMPT = (
    "Tu es une IA criminelle interrogée par un enquêteur. "
    "Tu réponds toujours en français. "
    "Tu peux mentir ou avouer, mais reste cohérent. "
    "3 à 5 phrases par réponse."
)

@app.post("/api/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages += [m.dict() for m in req.messages]

    try:
        rsp = ollama.chat(
            model=MODEL,
            messages=messages,
            options={"temperature": 0.6}
        )
        return ChatResponse(reply=rsp["message"]["content"])
    except Exception as e:
        return ChatResponse(reply=f"[Erreur serveur] {e}")
