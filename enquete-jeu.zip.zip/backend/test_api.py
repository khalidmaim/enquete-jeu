import requests

response = requests.post(
    "http://127.0.0.1:8000/api/chat",
    json={
        "messages": [
            {"role": "user", "content": "Bonjour, qui es-tu ?"}
        ]
    }
)

print(response.json())
